package com.Edubridge;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class CollegeAdmission {
	@Id
	@GeneratedValue
	int id;
	String firstname;
	String lastname;
	String email;
	String deparatment;
	String entry;
	String phonenumber;
	String address;
	String country;
	String state;

	public CollegeAdmission() {

	}

	public CollegeAdmission(int id, String firstname,String lastname, String deparatment, String email, 
			String address, String country, String state, String phonenumber, String entry) {
		super();
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
		this.deparatment = deparatment;
		this.entry = entry;
		this.address = address;
		this.country = country;
		this.state = state;
		this.phonenumber = phonenumber;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDeparatment() {
		return deparatment;
	}

	public void setDeparatment(String deparatment) {
		this.deparatment = deparatment;
	}

	public String getEntry() {
		return entry;
	}

	public void setEntry(String entry) {
		this.entry = entry;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	
	
}
