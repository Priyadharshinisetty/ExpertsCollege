package com.Edubridge;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class CollegeStudentdetails {
	@Id
	int id;
	String name;
	String deparatment;
	String email;
	String higherschoolname;
	String matricschoolname;
	int highermark;
	int matricmark;
	String phonenumber;
	String address;
	String country;
	String state;

	public CollegeStudentdetails() {

	}

	public CollegeStudentdetails(int id, String name, String deparatment, String email, String higherschoolname,
			String matricschoolname, String address, String country, String state, String phonenumber, int highermark,
			int matricmark) {
		super();
		this.id = id;
		this.email = email;
		this.name = name;
		this.deparatment = deparatment;
		this.higherschoolname = higherschoolname;
		this.matricschoolname = matricschoolname;
		this.address = address;
		this.country = country;
		this.state = state;
		this.phonenumber = phonenumber;
		this.highermark = highermark;
		this.matricmark = matricmark;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDeparatment() {
		return deparatment;
	}

	public void setDeparatment(String deparatment) {
		this.deparatment = deparatment;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getHigherschoolname() {
		return higherschoolname;
	}

	public void setHigherschoolname(String higherschoolname) {
		this.higherschoolname = higherschoolname;
	}

	public String getMatricschoolname() {
		return matricschoolname;
	}

	public void setMatricschoolname(String matricschoolname) {
		this.matricschoolname = matricschoolname;
	}

	public int getHighermark() {
		return highermark;
	}

	public void setHighermark(int highermark) {
		this.highermark = highermark;
	}

	public int getMatricmark() {
		return matricmark;
	}

	public void setMatricmark(int matricmark) {
		this.matricmark = matricmark;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}


}
