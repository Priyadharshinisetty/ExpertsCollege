package com.Edubridge;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class CollegeStaffdetails {
	@Id
	int id;
	String name;
	String emailid;
	int age;
	String phonenumber;
	String address;
	String country;
	String state;
	String qualification;
	public CollegeStaffdetails() {

	}

	public CollegeStaffdetails(int id, String name, String emailid,String qualification,
			String address, String country, String state, String phonenumber, int age) {
		super();
		this.id = id;
		this.emailid = emailid;
		this.name = name;
		this.qualification = qualification;
		this.age = age;
		this.address = address;
		this.country = country;
		this.state = state;
		this.phonenumber = phonenumber;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}


}
