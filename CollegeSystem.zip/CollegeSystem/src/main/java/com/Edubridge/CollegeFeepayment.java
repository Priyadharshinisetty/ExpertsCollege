package com.Edubridge;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class CollegeFeepayment {
	int id;
	@Id 
	@GeneratedValue
	int rollno;
	String month;
	int amount;
	String receivedate;
	public CollegeFeepayment() {

	}

	public CollegeFeepayment(int id,int rollno, String month,int amount,String receivedate) {
		super();
		this.id = id;
		this.rollno = rollno;
		this.month = month;
		this.amount = amount;
		this.receivedate = receivedate;
	}

	public int getRollno() {
		return rollno;
	}

	public void setRollno(int rollno) {
		this.rollno = rollno;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getReceivedate() {
		return receivedate;
	}

	public void setReceivedate(String receivedate) {
		this.receivedate = receivedate;
	}


}
