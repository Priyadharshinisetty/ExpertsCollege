package com.Edubridge.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Edubridge.CollegeAdmission;
import com.Edubridge.Service.CollegeAdmissionService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class CollegeAdmissionController {
	@Autowired
	CollegeAdmissionService cass;

	@PostMapping("insertAdmission")
	public CollegeAdmission savep(@RequestBody CollegeAdmission p) {
		cass.saveAdmission(p);
		return p;
	}

	
}
