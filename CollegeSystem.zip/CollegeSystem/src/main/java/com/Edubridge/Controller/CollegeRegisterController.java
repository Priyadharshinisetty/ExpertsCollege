package com.Edubridge.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Edubridge.CollegeRegister;
import com.Edubridge.Service.CollegeRegisterService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class CollegeRegisterController {
	@Autowired
	CollegeRegisterService cacs;
	
	@PostMapping("insertRegister")
	public CollegeRegister savep(@RequestBody CollegeRegister p) {
		cacs.saveRegister(p);
		return p;
	}

}
