package com.Edubridge.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Edubridge.CollegeAddstudent;
import com.Edubridge.CollegeAddstudentmarks;
import com.Edubridge.Service.CollegeAddstudentmarksService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class CollegeAddstudentmarksController {
	@Autowired
	CollegeAddstudentmarksService cacs;
	
	@PostMapping("insertStudentmark")
	public CollegeAddstudentmarks savep(@RequestBody CollegeAddstudentmarks p) {
		cacs.saveAddstudentmarks(p);
		return p;
	}
	
	@GetMapping("viewStudentsmarks")
	public List<CollegeAddstudentmarks> getAll() {
		return cacs.getAllAddstudentmarksdetails();
	}

	// get method for single player

	public CollegeAddstudentmarks getp(@PathVariable int id) {
		return cacs.getAddstudentmarksdetails(id);

	}
	
	@PostMapping("viewStudentmarksById")
	public CollegeAddstudentmarks getStudent(@RequestBody CollegeAddstudentmarks id) {
		int id1=id.getRollno();
		return cacs.getStudentmarksById(id1);
	}
	
}
