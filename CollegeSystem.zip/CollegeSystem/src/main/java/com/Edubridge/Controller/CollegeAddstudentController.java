package com.Edubridge.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Edubridge.CollegeAddstudent;
import com.Edubridge.Service.CollegeAddstudentService;

@RestController
@CrossOrigin(origins = "*")
public class CollegeAddstudentController {

	@Autowired
	CollegeAddstudentService cass;


	@PostMapping("viewStudentById")
	public CollegeAddstudent getStudent(@RequestBody CollegeAddstudent id) {
		int id1=id.getRollno();
		return cass.getStudentById(id1);
	}
	
	
	// post or add a student

	@PostMapping("insertAddstudent")
	public CollegeAddstudent savep(@RequestBody CollegeAddstudent p) {
		cass.saveStudent(p);
		return p;
	}

	@GetMapping("viewStudents")
	public List<CollegeAddstudent> getAll() {
		return cass.getAllAddstudentdetails();
	}

	// get method for single player

	public CollegeAddstudent getp(@PathVariable int id) {
		return cass.getAddstudentdetails(id);

	}
}
