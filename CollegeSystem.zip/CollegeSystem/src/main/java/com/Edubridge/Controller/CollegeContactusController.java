package com.Edubridge.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Edubridge.CollegeContactus;
import com.Edubridge.Service.CollegeContactusService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class CollegeContactusController {
	@Autowired
	CollegeContactusService ccs;

	@PostMapping("insertContact")
	public CollegeContactus savep(@RequestBody CollegeContactus p) {
		ccs.saveContactus(p);
		return p;
	}

}
