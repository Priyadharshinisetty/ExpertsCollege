package com.Edubridge.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Edubridge.CollegeAddCourse;
import com.Edubridge.CollegeAddstudent;
import com.Edubridge.Service.CollegeAddcourseService;
import com.Edubridge.Service.CollegeAddstudentService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class CollegeAddcourseController {
	@Autowired
	CollegeAddcourseService cacs;
	
	@PostMapping("insertAddcourse")
	public CollegeAddCourse savep(@RequestBody CollegeAddCourse p) {
		cacs.saveAddcourse(p);
		return p;
	}
	
}
