package com.Edubridge;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class CollegeStudentlogin {
	@Id
	String email;
	String password;
	
	public CollegeStudentlogin() {

	}

	public CollegeStudentlogin(String email,String password) {
		super();
		this.email = email;
		this.password = password;
		
	}
}
