package com.Edubridge;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class CollegeAddstudentmarks {
	@Id 
	int rollno;
	int id;
	String deparatment;
	int mark;
	String subject;
	String year;
	public CollegeAddstudentmarks() {

	}

	public CollegeAddstudentmarks(int id,int rollno, String deparatment,int mark,String year , String subject) {
		super();
		this.id = id;
		this.rollno = rollno;
		this.deparatment = deparatment;
		this.subject = subject;
		this.mark = mark;
		this.year = year;
	}

	public int getRollno() {
		return rollno;
	}

	public void setRollno(int rollno) {
		this.rollno = rollno;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDeparatment() {
		return deparatment;
	}

	public void setDeparatment(String deparatment) {
		this.deparatment = deparatment;
	}

	public int getMark() {
		return mark;
	}

	public void setMark(int mark) {
		this.mark = mark;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

}
