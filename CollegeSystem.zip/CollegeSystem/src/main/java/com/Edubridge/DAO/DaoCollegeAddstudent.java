package com.Edubridge.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Edubridge.CollegeAddstudent;

public interface DaoCollegeAddstudent extends JpaRepository<CollegeAddstudent,Integer> {

}
