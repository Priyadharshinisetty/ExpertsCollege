package com.Edubridge.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Edubridge.CollegeStafflogin;

public interface DaoCollegeStafflogin extends JpaRepository<CollegeStafflogin,Integer>{
	CollegeStafflogin findByEmail(String email);

}
