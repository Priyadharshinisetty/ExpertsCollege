package com.Edubridge.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Edubridge.CollegeAddstudentmarks;

public interface DaoCollegeAddstudentmarks extends JpaRepository<CollegeAddstudentmarks,Integer> {

}
