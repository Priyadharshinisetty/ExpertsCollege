package com.Edubridge.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Edubridge.CollegeRegister;

public interface DaoCollegeRegister  extends JpaRepository<CollegeRegister,String>{
	CollegeRegister findByEmail(String email); 
}
