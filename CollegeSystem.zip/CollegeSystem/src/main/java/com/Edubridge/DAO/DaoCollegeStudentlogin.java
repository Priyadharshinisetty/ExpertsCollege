package com.Edubridge.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Edubridge.CollegeRegister;
import com.Edubridge.CollegeStudentlogin;

public interface DaoCollegeStudentlogin extends JpaRepository<CollegeStudentlogin,Integer>{
	CollegeStudentlogin findByEmail(String email);

}
