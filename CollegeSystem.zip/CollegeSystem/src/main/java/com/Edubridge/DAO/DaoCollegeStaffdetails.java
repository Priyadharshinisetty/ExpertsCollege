package com.Edubridge.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Edubridge.CollegeStaffdetails;

public interface DaoCollegeStaffdetails extends JpaRepository<CollegeStaffdetails,Integer> {

}
