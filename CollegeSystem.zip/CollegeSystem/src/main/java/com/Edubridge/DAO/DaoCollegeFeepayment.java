package com.Edubridge.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Edubridge.CollegeFeepayment;


public interface DaoCollegeFeepayment extends JpaRepository<CollegeFeepayment,Integer> {

}
