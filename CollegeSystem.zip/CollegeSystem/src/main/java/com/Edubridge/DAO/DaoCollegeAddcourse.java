package com.Edubridge.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Edubridge.CollegeAddCourse;

public interface DaoCollegeAddcourse extends JpaRepository<CollegeAddCourse,Integer> {

}
