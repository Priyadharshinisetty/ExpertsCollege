package com.Edubridge.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Edubridge.CollegeContactus;

public interface DaoCollegeContactus extends JpaRepository<CollegeContactus,Integer>{

}
