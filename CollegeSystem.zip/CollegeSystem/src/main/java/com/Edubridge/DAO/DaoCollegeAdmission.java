package com.Edubridge.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Edubridge.CollegeAdmission;

public interface DaoCollegeAdmission  extends JpaRepository<CollegeAdmission,Integer> {

}
