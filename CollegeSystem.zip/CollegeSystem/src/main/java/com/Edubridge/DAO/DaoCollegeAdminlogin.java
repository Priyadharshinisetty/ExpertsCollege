package com.Edubridge.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Edubridge.CollegeAdminlogin;
import com.Edubridge.CollegeRegister;

public interface DaoCollegeAdminlogin extends JpaRepository<CollegeAdminlogin,Integer>{
	CollegeAdminlogin findByEmail(String email);
}
