package com.Edubridge.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.Edubridge.CollegeStaffdetails;
import com.Edubridge.DAO.DaoCollegeStaffdetails;

@Service
public class CollegeStaffdetailsService {
	@Autowired
	DaoCollegeStaffdetails dcas;

	public CollegeStaffdetailsService() {

	}
	
	public List<CollegeStaffdetails> getAllCollegeStaffdetails() {
		return dcas.findAll();
	}

	// Get player by id
	public CollegeStaffdetails getCollegeStaffdetails(int id) {
		return dcas.getOne(id);
	}

}
