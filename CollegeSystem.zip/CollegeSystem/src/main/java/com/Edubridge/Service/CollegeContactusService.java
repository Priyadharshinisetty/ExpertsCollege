package com.Edubridge.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Edubridge.CollegeContactus;
import com.Edubridge.DAO.DaoCollegeContactus;

@Service
public class CollegeContactusService {
	@Autowired
	DaoCollegeContactus dcc;
	
	public CollegeContactusService() {

	}
	
	// post or save student
		public void saveContactus(CollegeContactus p) {
			dcc.save(p);
		}
	          

}
