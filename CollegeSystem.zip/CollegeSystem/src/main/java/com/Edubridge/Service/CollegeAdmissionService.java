package com.Edubridge.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Edubridge.CollegeAdmission;
import com.Edubridge.DAO.DaoCollegeAdmission;

@Service
public class CollegeAdmissionService {
	@Autowired
	DaoCollegeAdmission dca;
	
	public CollegeAdmissionService() {

	}
	
	// post or save student
		public void saveAdmission(CollegeAdmission p) {
			dca.save(p);
		}
}
