package com.Edubridge.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Edubridge.CollegeAddstudent;
import com.Edubridge.CollegeAddstudentmarks;
import com.Edubridge.DAO.DaoCollegeAddstudentmarks;

@Service
public class CollegeAddstudentmarksService {
	@Autowired
	DaoCollegeAddstudentmarks dcas;

	public CollegeAddstudentmarksService() {

	}

	// post or save student
	public void saveAddstudentmarks(CollegeAddstudentmarks p) {
		dcas.save(p);
	}

	public List<CollegeAddstudentmarks> getAllAddstudentmarksdetails() {
		return dcas.findAll();
	}

	// Get player by id
	public CollegeAddstudentmarks getAddstudentmarksdetails(int id) {
		return dcas.getOne(id);
	}
	
	public CollegeAddstudentmarks getStudentmarksById(int id) {
		
		Optional<CollegeAddstudentmarks> pm=dcas.findById(id);
		if(pm.isPresent()) {
			System.out.println(pm.get());
			return pm.get() ;
	                
		}else 
		return null;
	}
	
}
