package com.Edubridge.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Edubridge.CollegeAddstudentmarks;
import com.Edubridge.CollegeFeepayment;
import com.Edubridge.DAO.DaoCollegeFeepayment;

@Service
public class CollegeFeepaymentService {
	@Autowired
	DaoCollegeFeepayment dcfp;

	public CollegeFeepaymentService() {

	}

	// post or save student

	public void saveFeepayment(CollegeFeepayment p) {
		dcfp.save(p);

	}

    public CollegeFeepayment getPaymentById(int id) {
		
		Optional<CollegeFeepayment> pm=dcfp.findById(id);
		if(pm.isPresent()) {
			System.out.println(pm.get());
			return pm.get() ;
	                
		}else 
		return null;
	}
	
}
