package com.Edubridge.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.Edubridge.CollegeAddCourse;
import com.Edubridge.CollegeAddstudent;
import com.Edubridge.CollegeStaffdetails;
import com.Edubridge.DAO.DaoCollegeAddstudent;

@Service
public class CollegeAddstudentService {
	@Autowired
	DaoCollegeAddstudent dcas;

	public CollegeAddstudentService() {

	}

	public CollegeAddstudent getStudentById(int id) {
		
		Optional<CollegeAddstudent> pm=dcas.findById(id);
		if(pm.isPresent()) {
			System.out.println(pm.get());
			return pm.get() ;
	                
		}else 
		return null;
	}

	// post or save student
	public void saveStudent(CollegeAddstudent p) {
		dcas.save(p);
	}

	public List<CollegeAddstudent> getAllAddstudentdetails() {
		return dcas.findAll();
	}

	// Get player by id
	public CollegeAddstudent getAddstudentdetails(int id) {
		return dcas.getOne(id);
	}

}
