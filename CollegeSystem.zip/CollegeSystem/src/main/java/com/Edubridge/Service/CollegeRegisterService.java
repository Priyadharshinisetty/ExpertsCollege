package com.Edubridge.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Edubridge.CollegeRegister;
import com.Edubridge.DAO.DaoCollegeRegister;

@Service
public class CollegeRegisterService {
	@Autowired
	DaoCollegeRegister dcas;
	
	public CollegeRegisterService() {

	}
	
	// post or save student
		public void saveRegister(CollegeRegister p) {
			dcas.save(p);
		}

}
