package com.Edubridge;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class CollegeContactus {
	@Id
	@GeneratedValue
	int id;
	String name;
	String emailid;
	String message;
	String phonenumber;
	
	public CollegeContactus() {

	}

	public CollegeContactus(int id, String name,String emailid, String message, String phonenumber) {
		super();
		this.id = id;
		this.name = name;
		this.emailid = emailid;
		this.message = message;
		this.phonenumber = phonenumber;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	
	
}
