package com.Edubridge;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class CollegeAddCourse {
	@Id
	@GeneratedValue
	int id;
	String coursename;
	String deparatment;
	int subjectcount;
	public CollegeAddCourse() {

	}

	public CollegeAddCourse(int id, String coursename, String deparatment, int subjectcount) {
		super();
		this.id = id;
		this.coursename = coursename;
		this.subjectcount = subjectcount;
		this.deparatment = deparatment;	
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCoursename() {
		return coursename;
	}

	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}

	public String getDeparatment() {
		return deparatment;
	}

	public void setDeparatment(String deparatment) {
		this.deparatment = deparatment;
	}

	public int getSubjectcount() {
		return subjectcount;
	}

	public void setSubjectcount(int subjectcount) {
		this.subjectcount = subjectcount;
	}
	
	
	
}
