package com.Edubridge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollegeSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollegeSystemApplication.class, args);
	}

}
