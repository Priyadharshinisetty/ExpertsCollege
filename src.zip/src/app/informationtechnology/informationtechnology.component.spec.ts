import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InformationtechnologyComponent } from './informationtechnology.component';

describe('InformationtechnologyComponent', () => {
  let component: InformationtechnologyComponent;
  let fixture: ComponentFixture<InformationtechnologyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InformationtechnologyComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InformationtechnologyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
