import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-informationtechnology',
  templateUrl: './informationtechnology.component.html',
  styleUrls: ['./informationtechnology.component.css']
})
export class InformationtechnologyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
