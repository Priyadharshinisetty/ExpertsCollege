import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ece',
  templateUrl: './ece.component.html',
  styleUrls: ['./ece.component.css']
})
export class EceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
