import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewstudentc',
  templateUrl: './viewstudentc.component.html',
  styleUrls: ['./viewstudentc.component.css']
})
export class ViewstudentcComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
