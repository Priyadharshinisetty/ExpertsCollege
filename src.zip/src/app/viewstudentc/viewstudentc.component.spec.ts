import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewstudentcComponent } from './viewstudentc.component';

describe('ViewstudentcComponent', () => {
  let component: ViewstudentcComponent;
  let fixture: ComponentFixture<ViewstudentcComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewstudentcComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewstudentcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
