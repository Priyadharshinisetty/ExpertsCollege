import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewstudentmarksComponent } from './viewstudentmarks.component';

describe('ViewstudentmarksComponent', () => {
  let component: ViewstudentmarksComponent;
  let fixture: ComponentFixture<ViewstudentmarksComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewstudentmarksComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewstudentmarksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
