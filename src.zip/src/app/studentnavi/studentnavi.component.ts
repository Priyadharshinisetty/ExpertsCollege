import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studentnavi',
  templateUrl: './studentnavi.component.html',
  styleUrls: ['./studentnavi.component.css']
})
export class StudentnaviComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
