import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentnaviComponent } from './studentnavi.component';

describe('StudentnaviComponent', () => {
  let component: StudentnaviComponent;
  let fixture: ComponentFixture<StudentnaviComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StudentnaviComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StudentnaviComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
