import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eee',
  templateUrl: './eee.component.html',
  styleUrls: ['./eee.component.css']
})
export class EeeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
