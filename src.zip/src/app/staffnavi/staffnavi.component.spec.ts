import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StaffnaviComponent } from './staffnavi.component';

describe('StaffnaviComponent', () => {
  let component: StaffnaviComponent;
  let fixture: ComponentFixture<StaffnaviComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StaffnaviComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StaffnaviComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
