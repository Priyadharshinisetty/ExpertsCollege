import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-staffnavi',
  templateUrl: './staffnavi.component.html',
  styleUrls: ['./staffnavi.component.css']
})
export class StaffnaviComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
