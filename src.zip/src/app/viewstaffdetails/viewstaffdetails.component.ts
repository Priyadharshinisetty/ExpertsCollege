import { Component, OnInit } from '@angular/core';
import { CollegeService } from '../college.service';

@Component({
  selector: 'app-viewstaffdetails',
  templateUrl: './viewstaffdetails.component.html',
  styleUrls: ['./viewstaffdetails.component.css']
})
export class ViewstaffdetailsComponent implements OnInit {

  constructor(private ps:CollegeService) {
    this.viewStaffs();
   }
   staffs:any 
   viewStaffs(){
    this.ps.viewStaffs().subscribe((result:any)=>{this.staffs=result});
  }
  ngOnInit(): void {
  }

}
