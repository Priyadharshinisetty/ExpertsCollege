import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewstudentdetailsbynoComponent } from './viewstudentdetailsbyno.component';

describe('ViewstudentdetailsbynoComponent', () => {
  let component: ViewstudentdetailsbynoComponent;
  let fixture: ComponentFixture<ViewstudentdetailsbynoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewstudentdetailsbynoComponent ]
    })
    .compileComponents();
 
    fixture = TestBed.createComponent(ViewstudentdetailsbynoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
