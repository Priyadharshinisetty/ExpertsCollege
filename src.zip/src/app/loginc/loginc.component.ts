import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loginc',
  templateUrl: './loginc.component.html',
  styleUrls: ['./loginc.component.css']
})
export class LogincComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
