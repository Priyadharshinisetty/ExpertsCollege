import { Component, OnInit } from '@angular/core';
import { CollegeService } from '../college.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private ps:CollegeService) {
  }
    insertLogin(insertLogin1:any){
      this.ps.insertLogin1(insertLogin1.value).subscribe();
    }

  ngOnInit(): void {
  }

}
