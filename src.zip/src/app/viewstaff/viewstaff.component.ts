import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewstaff',
  templateUrl: './viewstaff.component.html',
  styleUrls: ['./viewstaff.component.css']
})
export class ViewstaffComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
